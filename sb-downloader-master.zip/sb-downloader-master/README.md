# `.sb` downloader

https://forkphorus.github.io/sb-downloader/

A downloader for Scratch 1, 2, or 3 projects.
